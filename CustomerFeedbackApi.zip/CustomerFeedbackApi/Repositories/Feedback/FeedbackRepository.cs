﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.Feedback
{
    public class FeedbackRepository : RepositoryBase<FeedbackModel>, IFeedbackRepository
    {
        public FeedbackRepository(CustomerDataContext dbContext) : base(dbContext)
        {
        }

        public async Task<FeedbackModel> AddFeedbackAsync(FeedbackModel feedback)
        {
            try {
                await AddAsync(feedback);

                await SaveChangesAsync();

                return feedback;
            }
            catch 
            (Exception ex) 
            {
                return null;
            }
            
        }

        public async Task<IEnumerable<FeedbackModel>> GetAllFeedback()
        {
            var Orders = await GetAllAsync();

            if (Orders != null && Orders.Any())
            {
                return Orders;
            }
            else return new List<FeedbackModel>();
        }
    }
}
