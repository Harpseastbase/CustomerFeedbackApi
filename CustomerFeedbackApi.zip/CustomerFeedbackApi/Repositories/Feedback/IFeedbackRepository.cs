﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.Feedback
{
    public interface IFeedbackRepository
    {
        Task<FeedbackModel> AddFeedbackAsync(FeedbackModel feedback);
        Task<IEnumerable<FeedbackModel>> GetAllFeedback();
    }
}
