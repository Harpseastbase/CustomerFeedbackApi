﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.FeedbackSendGrid
{
    public interface IFeedbackSendGridRepository
    {
        Task<FeedbackSendGridModel> AddFeedbackSendGridAsync(FeedbackSendGridModel feedbackSendGrid);
    }
}
