﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.FeedbackSendGrid
{
    public class FeedbackSendGridRepository : RepositoryBase<FeedbackSendGridModel>, IFeedbackSendGridRepository
    {
        public FeedbackSendGridRepository(CustomerDataContext dbContext) : base(dbContext)
        {

        }

        public async Task<FeedbackSendGridModel> AddFeedbackSendGridAsync(FeedbackSendGridModel feedbackSendGrid)
        {
            try
            {
                await AddAsync(feedbackSendGrid);

                await SaveChangesAsync();

                return feedbackSendGrid;
            }
            catch(Exception ex)
            {
                return null;
            }

        }
    }
}
