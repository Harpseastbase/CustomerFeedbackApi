﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories
{
    public abstract class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : class
    {
        protected CustomerDataContext DbContext;
        protected DbSet<TEntity> DbSet;

        protected RepositoryBase(CustomerDataContext dbContext)
        {
            DbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            DbSet = DbContext.Set<TEntity>();
        }

        public virtual IQueryable<TEntity> GetAll() => DbSet.AsNoTracking();

        public virtual async Task<List<TEntity>> GetAllAsync()
        {
            return await DbSet.AsNoTracking().ToListAsync();
        }

        public virtual async Task<IQueryable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate)
        {
            var result = await GetAll().Where(predicate).ToListAsync();
            return result.AsQueryable();
        }

        public virtual async Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await DbSet.CountAsync(predicate);
        }

        public virtual Task<bool> Exists(Expression<Func<TEntity, bool>> predicate)
        {
            return GetAll().AnyAsync(predicate);
        }

        public Task<TEntity> SingleOrDefaultAsync(Expression<Func<TEntity, bool>> predicate) => DbSet.SingleOrDefaultAsync(predicate);

        public async Task<TEntity> FirstOrDefaultAsync(Expression<Func<TEntity, bool>> predicate) =>
            await GetAll().FirstOrDefaultAsync(predicate);

        public async Task<List<TEntity>> ToListAsync(Expression<Func<TEntity, bool>> predicate) =>
        await GetAll().Where(predicate).ToListAsync();

        public async Task<TEntity> SingleAsync(Expression<Func<TEntity, bool>> predicate) =>
            await GetAll().SingleAsync(predicate);

        public async Task<TEntity> FirstAsync(Expression<Func<TEntity, bool>> predicate) =>
            await GetAll().FirstAsync(predicate);

        public virtual void Add(TEntity entity) => DbSet.Add(entity);

        public virtual async Task AddAsync(TEntity entity) => await DbSet.AddAsync(entity);

        public virtual async Task AddRangeAsync(IEnumerable<TEntity> entities) => await DbSet.AddRangeAsync(entities);

        public virtual void Update(TEntity entity) => DbSet.Update(entity);

        public virtual void Delete(TEntity entity) => DbSet.Remove(entity);

        public virtual async Task SaveChangesAsync() => await DbContext.SaveChangesAsync();

        public virtual Task<IDbContextTransaction> BeginTransactionAsync() => DbContext.Database.BeginTransactionAsync();
    }
}
