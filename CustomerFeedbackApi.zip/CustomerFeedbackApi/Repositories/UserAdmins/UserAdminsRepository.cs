﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.UserAdmins
{
    public class UserAdminsRepository : RepositoryBase<UserAdminsModel>, IUserAdminsRepository
    {
        public UserAdminsRepository(CustomerDataContext dbContext) : base(dbContext)
        {
        }

        public async Task<UserAdminsModel> AddUserAdminAsync(UserAdminsModel feedback)
        {
            try
            {
                await AddAsync(feedback);

                await SaveChangesAsync();

                return feedback;
            }
            catch
            (Exception ex)
            {
                return null;
            }

        }

        public async Task<UserAdminsModel> RegisterLogin(string email, string password)
        {
            var user = await FirstOrDefaultAsync(u => u.UserEmail == email && u.Password == password);

            if (user != null)
            {
                return user;
            }
            else return null;
        }

        public async Task<IEnumerable<UserAdminsModel>> GetUserAdmins()
        {
            var Orders = await GetAllAsync();

            if (Orders != null && Orders.Any())
            {
                return Orders;
            }
            else return new List<UserAdminsModel>();
        }

        public async Task<bool> DeleteUserAdmin(string UserId)
        {
            var User = await FirstOrDefaultAsync(u => u.Id == UserId);

            if (User != null)
            {
                DbContext.UserAdmins.Remove(User);
                await DbContext.SaveChangesAsync();
                return true;
            }
            else return false;
        }
    }
}
