﻿using CustomerFeedbackAPI.Data;

namespace CustomerFeedbackAPI.Repositories.UserAdmins
{
    public interface IUserAdminsRepository
    {
        Task<UserAdminsModel> AddUserAdminAsync(UserAdminsModel feedback);
        Task<IEnumerable<UserAdminsModel>> GetUserAdmins();
        Task<bool> DeleteUserAdmin(string UserId);
        Task<UserAdminsModel> RegisterLogin(string email, string password);
    }
}
