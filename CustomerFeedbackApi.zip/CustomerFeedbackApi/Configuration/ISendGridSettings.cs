﻿namespace CustomerFeedbackAPI.Configuration
{
    public interface ISendGridSettings
    {
        string? apiKey { get; set; }
    }
}
