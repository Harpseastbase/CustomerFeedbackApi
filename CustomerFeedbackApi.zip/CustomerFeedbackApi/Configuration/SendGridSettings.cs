﻿namespace CustomerFeedbackAPI.Configuration
{
    public class SendGridSettings : ISendGridSettings
    {
        public string? apiKey { get; set; }
    }
}
