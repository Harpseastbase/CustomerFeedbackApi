﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace CustomerFeedbackAPI.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class UserAdminsController : ControllerBase
    {
        private readonly IEmailService _emailService;
        private readonly IUserAdminsService _userAdminsService;
        public UserAdminsController(IEmailService emailService, IUserAdminsService userAdminsService)
        {
            _emailService = emailService;
            _userAdminsService = userAdminsService;
        }


        [HttpPost("AddUserAdmin")]
        public async Task<ActionResult> SubmitFeedback(UserAdminsRequestModel userAdminsRequestModel)
        {
            try
            {
                var response = await _userAdminsService.AddUserAdmin(userAdminsRequestModel);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPost("Login")]
        public async Task<ActionResult> Login(UserAdminsRequestModel userAdminsRequestModel)
        {
            try
            {
                var response = await _userAdminsService.Login(userAdminsRequestModel);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [Authorize]
        [HttpGet("GetAllUserAdmins")]
        public async Task<ActionResult<IEnumerable<UserAdminsModel>>> GetAllUserAdmins()
        {
            try
            {
                var userAdmins = await _userAdminsService.GetAllUserAdmins();
                return Ok(userAdmins);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [Authorize]
        [HttpDelete("DeleteUserAdmin/{UserId}")]
        public async Task<ActionResult> DeleteUserAdmin(string UserId)
        {
            try
            {
                var results = await _userAdminsService.DeleteUserAdmin(UserId);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }
    }
}
