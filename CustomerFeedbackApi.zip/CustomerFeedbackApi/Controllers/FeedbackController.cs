﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Net;

namespace CustomerFeedbackAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FeedbackController : ControllerBase
    {
        private readonly IEmailService _emailService;
        private readonly IFeedbackService _feedbackService;
        public FeedbackController(IFeedbackService feedbackService, IEmailService emailService)
        {
            _emailService = emailService;
            _feedbackService = feedbackService;
        }

        //[Authorize]
        [HttpPost("SubmitFeedback")]
        public async Task<ActionResult> SubmitFeedback(FeedbackRequestModel feedback)
        {
            try
            {
                var response = await _feedbackService.AddFeedback(feedback);

                await _emailService.SendEmailAsync(feedback.UserEmail, "New Feedback Submitted", "A new feedback has been submitted.");
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }

           

            //return Ok();
        }

        [Authorize]
        [HttpGet("GetAllFeedback")]
        public async Task<ActionResult<IEnumerable<FeedbackModel>>> GetAllFeedback()
        {
            try
            {
                var feedbacks = await _feedbackService.GetAllFeedback();
                return Ok(feedbacks);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost("SendGridWebhook")]
        public async Task<IActionResult> ReceiveEvents([FromBody] JArray events)
        {
            try
            {
                foreach (var evt in events)
                {
                    System.Diagnostics.Debug.WriteLine(evt.ToString());

                    var webHookData = new FeedbackSendGridRequestModel()
                    {
                        Event = evt["event"]?.ToString(),
                        Timestamp = evt["timestamp"]?.ToString(),
                        UserEmail = evt["email"]?.ToString()
                    };

                    await _feedbackService.GetAllFeedback();
                   
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.BadRequest, ex.Message);
            }
        }
    }
}
