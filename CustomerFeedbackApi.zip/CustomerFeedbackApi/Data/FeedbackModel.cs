﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustomerFeedbackAPI.Data
{
    [Table("Feedback", Schema = "dbo")]
    public class FeedbackModel
    {
        [Key]
        public string Id { get; set; }
        public string UserName { get; set; }
        [Required]
        public string UserEmail { get; set; }
        [Required]
        public string Content { get; set; }
        public DateTime DateSubmitted { get; set; }
    }
}
