﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustomerFeedbackAPI.Data
{
    [Table("UserAdmins", Schema = "dbo")]
    public class UserAdminsModel
    {
        [Key]
        public string Id { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string UserEmail { get; set; }
        [Required]
        public string ClientSecret { get; set; }
        [Required]
        public string Password { get; set; }
        public DateTime Created { get; set; }
    }
}
