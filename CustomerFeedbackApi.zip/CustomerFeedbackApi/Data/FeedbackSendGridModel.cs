﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustomerFeedbackAPI.Data
{
    [Table("SendGridEmailFeedback", Schema = "dbo")]
    public class FeedbackSendGridModel
    {
        [Key]
        public string Id { get; set; }
        
        [Required]
        public string Event { get; set; }
        
        [Required]
        public string UserEmail { get; set; }

        [Required]
        public string Timestamp { get; set; }
        
        public DateTime DateSubmitted { get; set; }
    }
}
