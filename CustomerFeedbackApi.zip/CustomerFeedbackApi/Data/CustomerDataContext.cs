﻿using Microsoft.EntityFrameworkCore;

namespace CustomerFeedbackAPI.Data
{
    public class CustomerDataContext : DbContext
    {
        public CustomerDataContext(DbContextOptions<CustomerDataContext> options) : base(options) { }
        public DbSet<FeedbackModel> Feedback { get; set; }
        public DbSet<FeedbackSendGridModel> SendGridEmailFeedback { get; set; }
        public DbSet<UserAdminsModel> UserAdmins { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FeedbackModel>().HasKey(f => f.Id);
            modelBuilder.Entity<UserAdminsModel>().HasKey(f => f.Id);
            modelBuilder.Entity< FeedbackSendGridModel>().HasKey(f => f.Id);

            base.OnModelCreating(modelBuilder);
        }
    }
}
