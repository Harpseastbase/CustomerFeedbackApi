﻿namespace CustomerFeedbackAPI.Models
{
    public class EmailHistory
    {
        public int Id { get; set; }  
        public string? To { get; set; }  
        public string? Subject { get; set; }  
        public string? Body { get; set; } 
        public DateTime SentDate { get; set; } 
        public string? Status { get; set; }
        public bool Success { get; set; }
    }
}
