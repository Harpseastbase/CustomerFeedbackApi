﻿namespace CustomerFeedbackAPI.Models.ResponseModel
{
    public class FeedbackResponseModel
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string Content { get; set; }
        public DateTime DateSubmitted { get; set; } = DateTime.UtcNow;
    }
}
