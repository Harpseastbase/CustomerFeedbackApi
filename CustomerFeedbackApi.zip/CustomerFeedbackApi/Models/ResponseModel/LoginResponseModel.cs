﻿namespace CustomerFeedbackAPI.Models.ResponseModel
{
    public class LoginResponseModel
    {
        public string AccessToken { get; set; }
    }
}
