﻿namespace CustomerFeedbackAPI.Models.ResponseModel
{
    public class UserAdminsResponseModel
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string ClientSecret { get; set; }
        public DateTime Created {  get; set; }
    }
}
