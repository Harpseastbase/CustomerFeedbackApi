﻿namespace CustomerFeedbackAPI.Models.RequestModel
{
    public class LoginRequestModel
    {
        public string Email { get; set; }   
        public string Password { get; set; }
    }
}
