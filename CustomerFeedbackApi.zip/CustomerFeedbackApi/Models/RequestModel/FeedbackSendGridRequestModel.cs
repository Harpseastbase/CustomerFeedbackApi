﻿namespace CustomerFeedbackAPI.Models.RequestModel
{
    public class FeedbackSendGridRequestModel
    {
        public string? Event { get; set; }
        public string? UserEmail { get; set; }
        public string? Timestamp { get; set; }
        public DateTime DateSubmitted { get; set; }
    }
}
