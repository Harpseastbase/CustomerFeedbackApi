﻿namespace CustomerFeedbackAPI.Models.RequestModel
{
    public class FeedbackRequestModel
    {
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string Content { get; set; }
        public DateTime DateSubmitted { get; set; }
    }
}
