﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Models.ResponseModel;

namespace CustomerFeedbackAPI.Services.Contracts
{
    public interface IFeedbackService
    {
        Task<FeedbackModel> AddFeedback(FeedbackRequestModel feedbackRequestModel);
        Task<IEnumerable<FeedbackResponseModel>> GetAllFeedback();
    }
}
