﻿namespace CustomerFeedbackAPI.Services.Contracts
{
    public interface IEmailService
    {
        Task SendEmailAsync(string adminEmail, string subject, string message);
    }
}
