﻿using CustomerFeedbackAPI.Security;

namespace CustomerFeedbackAPI.Services.Contracts
{
    public interface IIdentityService
    {
        IdentityToken GenerateJSONWebToken(string clientSecret, string userId, string role, string platform, string scope);
        string GenerateClientSecret(int length);
    }
}
