﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;

namespace CustomerFeedbackAPI.Services.Contracts
{
    public interface IFeedbackSendGridService
    {
        Task<FeedbackSendGridModel> AddFeedbackSendGrid(FeedbackSendGridRequestModel feedbackSendGridRequestModel);
    }
}
