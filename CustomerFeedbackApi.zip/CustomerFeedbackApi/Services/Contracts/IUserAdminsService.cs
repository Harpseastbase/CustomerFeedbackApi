﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Models.ResponseModel;

namespace CustomerFeedbackAPI.Services.Contracts
{
    public interface IUserAdminsService
    {
        Task<UserAdminsModel> AddUserAdmin(UserAdminsRequestModel userAdminsRequestModel);
        Task<IEnumerable<UserAdminsResponseModel>> GetAllUserAdmins();
        Task<bool> DeleteUserAdmin(string UserId);
        Task<LoginResponseModel> Login(UserAdminsRequestModel userAdminsRequestModel);
    }
}
