﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Repositories.FeedbackSendGrid;
using CustomerFeedbackAPI.Services.Contracts;

namespace CustomerFeedbackAPI.Services.Implementation
{
    public class FeedbackSendGridService : IFeedbackSendGridService
    {
        private readonly IFeedbackSendGridRepository _feedbackSendGridRepository;
        public FeedbackSendGridService(IFeedbackSendGridRepository feedbackSendGridRepository)
        {
            _feedbackSendGridRepository = feedbackSendGridRepository;
        }

        public async Task<FeedbackSendGridModel> AddFeedbackSendGrid(FeedbackSendGridRequestModel feedbackSendGridRequestModel)
        {
            var feedbackSendGrid = new FeedbackSendGridModel
            {
                Id = Guid.NewGuid().ToString(),
                Event = feedbackSendGridRequestModel.Event,
                DateSubmitted = DateTime.UtcNow,
                UserEmail = feedbackSendGridRequestModel.UserEmail,
                Timestamp = feedbackSendGridRequestModel.Timestamp
            };

            await _feedbackSendGridRepository.AddFeedbackSendGridAsync(feedbackSendGrid);

            return feedbackSendGrid;
        }
    }
}
