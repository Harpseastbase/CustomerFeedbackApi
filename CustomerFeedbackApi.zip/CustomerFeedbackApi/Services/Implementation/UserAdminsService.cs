﻿
using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Models.ResponseModel;
using CustomerFeedbackAPI.Repositories.UserAdmins;
using CustomerFeedbackAPI.Security;
using CustomerFeedbackAPI.Services.Contracts;

namespace CustomerFeedbackAPI.Services.Implementation
{
    public class UserAdminsService : IUserAdminsService
    {
        private readonly IUserAdminsRepository _userAdminsRepository;
        private readonly IIdentityService _identityService;
        public UserAdminsService(IUserAdminsRepository userAdminsRepository, IIdentityService identityService)
        {
            _identityService = identityService;
            _userAdminsRepository = userAdminsRepository;
        }
        public async Task<UserAdminsModel> AddUserAdmin(UserAdminsRequestModel userAdminsRequestModel)
        {
            var feedback = new UserAdminsModel
            {
                Id = Guid.NewGuid().ToString(),
                Created = DateTime.Now,
                UserEmail = userAdminsRequestModel.UserEmail,
                UserName = userAdminsRequestModel.UserName,
                ClientSecret = _identityService.GenerateClientSecret(32),
                Password = PasswordHelper.HashPassword(userAdminsRequestModel.Password),
            };

            await _userAdminsRepository.AddUserAdminAsync(feedback);

            return feedback;
        }

        public async Task<IEnumerable<UserAdminsResponseModel>> GetAllUserAdmins()
        {
            var response = await _userAdminsRepository.GetUserAdmins();

            return response.Select(val => new UserAdminsResponseModel
            {
                Id = val.Id,
                ClientSecret = val.ClientSecret,
                UserEmail = val.UserEmail,
                UserName = val.UserName,
                Created = val.Created,
            }).ToList();
        }


        public async Task<bool> DeleteUserAdmin(string UserId) 
        {
            return  await _userAdminsRepository.DeleteUserAdmin(UserId);
        }

        public async Task<LoginResponseModel> Login(UserAdminsRequestModel userAdminsRequestModel)
        {
            var response = await _userAdminsRepository.RegisterLogin(userAdminsRequestModel.UserEmail, PasswordHelper.HashPassword(userAdminsRequestModel.Password));

            if (response != null)
            {
                return new LoginResponseModel { AccessToken = _identityService.GenerateJSONWebToken(response.ClientSecret, response.Id, "User", "Customer App", "UserLogin").AccessToken };
            }
            else return new LoginResponseModel
            {
                AccessToken = ""
            };
        }
    }
}
