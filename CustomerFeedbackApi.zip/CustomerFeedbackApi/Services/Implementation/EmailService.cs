﻿using CustomerFeedbackAPI.Configuration;
using CustomerFeedbackAPI.Services.Contracts;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Net.Mail;

namespace CustomerFeedbackAPI.Services.Implementation
{
    public class EmailService : IEmailService
    {
        private readonly SendGridSettings _sendGridSettings;

        public EmailService(IOptions<SendGridSettings> sendGridSettings) 
        {
            _sendGridSettings = sendGridSettings.Value ?? throw new ArgumentNullException(nameof(sendGridSettings));
        }

        public async Task SendEmailAsync(string adminEmail, string subject, string message) 
        {
            var client = new SendGridClient(_sendGridSettings.apiKey);
            var from = new EmailAddress("Harps@techdev-it.co.za", "Test Mail");
            subject = "Testing SendGrid Integration";
            var to = new EmailAddress(adminEmail, "Test User");
            var plainTextContent = "Prosoft IT Test";
            var htmlContent = "<strong>I love coding...</strong>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);


            var res = await client.SendEmailAsync(msg).ConfigureAwait(false);


        }
    }
}
