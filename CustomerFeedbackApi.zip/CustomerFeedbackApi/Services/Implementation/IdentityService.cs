﻿using CustomerFeedbackAPI.Configuration;
using CustomerFeedbackAPI.Security;
using CustomerFeedbackAPI.Services.Contracts;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace CustomerFeedbackAPI.Services.Implementation
{
    public class IdentityService : IIdentityService
    {
        private readonly JwtConfig _jwtConfig;
        public IdentityService(IOptions<JwtConfig> jwtConfig) 
        {
            _jwtConfig = jwtConfig.Value ?? throw new ArgumentNullException();
        }

        public IdentityToken GenerateJSONWebToken(string clientSecret, string userId, string role, string platform, string scope)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var Key = Encoding.ASCII.GetBytes(_jwtConfig.Key);
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim("client_secret", clientSecret),
                new Claim(ClaimTypes.Role, role),
                new Claim("customerfeedback_client", userId),
                new Claim("platform", platform),
                new Claim("scope", scope)
            }),
                Expires = DateTime.Now.AddMinutes(30),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = "https://auth.techdev-it.co.za",
                Audience = "https://api.techdev-it.co.za"
            };

            var accessToken = tokenHandler.CreateToken(tokenDescriptor);
            var accessTokenString = tokenHandler.WriteToken(accessToken);
            var refreshToken = GenerateRefreshToken();

            var response = new IdentityToken()
            {
                UserId = userId,
                AccessToken = accessTokenString,
                ExpiresIn = Math.Abs((int)accessToken.ValidTo.Subtract(DateTime.Now).TotalSeconds),
                TokenType = "Bearer",
                JwtSymmetricKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_jwtConfig.Key)).ToString(),
                RefreshToken = refreshToken,
                Scope = scope
            };

            return response;
        }

        public string GenerateClientSecret(int length = 32)
        {
            using (var GeneratedVal = new RNGCryptoServiceProvider())
            {
                var buffer = new byte[length];
                GeneratedVal.GetBytes(buffer);
                return Convert.ToBase64String(buffer);
            }
        }

        private string GenerateRefreshToken()
        {
            return Guid.NewGuid().ToString("N");
        }
    }
}
