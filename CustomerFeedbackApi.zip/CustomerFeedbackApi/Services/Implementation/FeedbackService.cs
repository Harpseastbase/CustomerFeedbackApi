﻿using CustomerFeedbackAPI.Data;
using CustomerFeedbackAPI.Models.RequestModel;
using CustomerFeedbackAPI.Models.ResponseModel;
using CustomerFeedbackAPI.Repositories.Feedback;
using CustomerFeedbackAPI.Services.Contracts;

namespace CustomerFeedbackAPI.Services.Implementation
{
    public class FeedbackService : IFeedbackService
    {
        private readonly IFeedbackRepository _feedbackRepository;
        public FeedbackService(IFeedbackRepository feedbackRepository) 
        {
             _feedbackRepository = feedbackRepository;
        }

        public async Task<FeedbackModel> AddFeedback(FeedbackRequestModel feedbackRequestModel)
        {
            var feedback = new FeedbackModel
            {
                Id = Guid.NewGuid().ToString(),
                Content = feedbackRequestModel.Content,
                DateSubmitted = DateTime.UtcNow,
                UserEmail = feedbackRequestModel.UserEmail,
                UserName = feedbackRequestModel.UserName
            };

            await _feedbackRepository.AddFeedbackAsync(feedback);

            return feedback;
        }

        public async Task<IEnumerable<FeedbackResponseModel>> GetAllFeedback() 
        {
            var response = await _feedbackRepository.GetAllFeedback();

            return response.Select(val => new FeedbackResponseModel 
            {
                Id = val.Id,
                Content = val.Content,
                DateSubmitted = val.DateSubmitted,  
                UserEmail = val.UserEmail,  
                UserName = val.UserName
            }).ToList();
        }

    }
}
